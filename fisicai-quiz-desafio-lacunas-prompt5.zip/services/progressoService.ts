import AsyncStorage from '@react-native-async-storage/async-storage';

import type { NivelDificuldade } from '../types';

const STORAGE_KEY = '@fisicai:progresso-sessoes';

export type TipoSessaoProgresso =
  | 'flashcards'
  | 'memoria'
  | 'quiz'
  | 'desafio'
  | 'lacunas';

export type RegistroProgressoSessao = {
  id: string;
  tipo: TipoSessaoProgresso;
  modulo: string;
  dificuldade: NivelDificuldade | 'todas';
  acertos: number;
  total: number;
  tempoSegundos: number;
  criadoEm: string;
};

async function listarRegistros(): Promise<RegistroProgressoSessao[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);

  if (!raw) {
    return [];
  }

  try {
    return JSON.parse(raw) as RegistroProgressoSessao[];
  } catch {
    return [];
  }
}

export async function salvarProgressoSessao(
  registro: Omit<RegistroProgressoSessao, 'id' | 'criadoEm'>,
): Promise<RegistroProgressoSessao> {
  const registros = await listarRegistros();

  const novoRegistro: RegistroProgressoSessao = {
    ...registro,
    id: `${registro.tipo}-${registro.modulo}-${Date.now()}`,
    criadoEm: new Date().toISOString(),
  };

  const atualizados = [novoRegistro, ...registros];

  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(atualizados));

  return novoRegistro;
}

export async function obterProgressoSessoes(): Promise<
  RegistroProgressoSessao[]
> {
  return listarRegistros();
}

export async function limparProgressoSessoes(): Promise<void> {
  await AsyncStorage.removeItem(STORAGE_KEY);
}
