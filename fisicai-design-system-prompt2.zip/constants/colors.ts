export const colors = {
  primary: '#0289e0',
  primaryLight: '#e0f2fe',

  secondary: '#f9ac03',
  secondaryLight: '#fff7d6',

  success: '#22c55e',
  successLight: '#dcfce7',

  error: '#ef4444',
  errorLight: '#fee2e2',

  warning: '#f9ac03',
  warningLight: '#fff7d6',

  background: '#f8fafc',
  surface: '#f3faff',
  card: '#ffffff',

  text: '#1a1a1a',
  textMuted: '#4b5563',
  textSoft: '#64748b',

  border: '#e5e7eb',
  borderStrong: '#0289e0',

  disabledBackground: '#e0f2fe',
  disabledText: '#0289e0',

  transparent: 'transparent',
} as const;

export type ColorToken = keyof typeof colors;
