import { router } from 'expo-router';
import { ScrollView, Text, View } from 'react-native';

import { Header } from '../../components/Header';
import { ModuloCard } from '../../components/ModuloCard';
import { APP_INFO, HOME_QUICK_ACCESS } from '../../constants';

export default function HomeScreen(): JSX.Element {
  return (
    <View className="flex-1 bg-background">
      <Header title="FisicAI" />

      <ScrollView
        className="flex-1"
        contentContainerClassName="px-4 pb-8 pt-5"
        showsVerticalScrollIndicator={false}
      >
        <View className="mb-5 rounded-xl border border-border bg-surface p-4">
          <Text className="font-arial text-sm font-bold uppercase tracking-widest text-primary">
            {APP_INFO.shortInstitution}
          </Text>

          <Text className="mt-2 font-arial text-2xl font-bold leading-8 text-text">
            Física com identidade, prática e inteligência.
          </Text>

          <Text className="mt-3 font-arial text-sm leading-5 text-textMuted">
            Acesse conteúdos, flashcards, questões, jogos, simulações e ajuda
            com IA em uma experiência visual alinhada à identidade institucional
            da UNIVASF.
          </Text>

          <View className="mt-4 self-start rounded-full bg-secondary px-4 py-2">
            <Text className="font-arial text-xs font-bold uppercase tracking-wide text-text">
              Ensino de Física
            </Text>
          </View>
        </View>

        <View className="mb-4 flex-row items-center justify-between">
          <Text className="font-arial text-xl font-bold text-primary">
            Módulos principais
          </Text>

          <View className="rounded-full bg-secondary px-3 py-1">
            <Text className="font-arial text-xs font-bold text-text">
              {HOME_QUICK_ACCESS.length} acessos
            </Text>
          </View>
        </View>

        <View className="flex-row flex-wrap justify-between gap-y-4">
          {HOME_QUICK_ACCESS.map((item) => (
            <ModuloCard
              key={item.id}
              title={item.title}
              description={item.description}
              icon={item.icon}
              onPress={() => router.push(item.href)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
